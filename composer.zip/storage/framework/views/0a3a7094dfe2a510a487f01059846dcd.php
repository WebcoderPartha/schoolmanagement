
<?php $__env->startSection('title'); ?>
    Manage Grade
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Grade List <a href="<?php echo e(route('grades.add')); ?>" class="btn btn-primary float-right">Add Grade</a></h4>
                    </div>
                    <div class="card-body">


                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Grade Name</th>
                                    <th>Grade Point</th>
                                    <th>Start Mark</th>
                                    <th>End Mark</th>
                                    <th>Point Range</th>
                                    <th>Remarks</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($grades) > 0): ?>
                                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($grade->grade_name); ?></td>
                                            <td><?php echo e($grade->grade_point); ?></td>
                                            <td><?php echo e($grade->start_marks); ?></td>
                                            <td><?php echo e($grade->end_marks); ?></td>
                                            <td><?php echo e($grade->start_point); ?> - <?php echo e($grade->end_point); ?></td>
                                            <td><?php echo e($grade->remarks); ?></td>
                                            <td>

                                                <a href="<?php echo e(route('grades.edit', $grade->id)); ?>" type="button" class="btn btn-sm btn-warning btn-icon-text">
                                                    <i class="typcn typcn-edit btn-icon-prepend"></i>
                                                    Edit
                                                </a>
                                                <a id="delete" href="<?php echo e(route('grades.delete', $grade->id)); ?>" type="button" class="btn btn-sm btn-danger btn-icon-text">
                                                    <i class="typcn typcn-delete-outline btn-icon-prepend"></i>
                                                    Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8">  <h4 class="text-center">No grades found.</h4></td>
                                    </tr>

                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\slms\resources\views/backend/manage_grade/grade_view.blade.php ENDPATH**/ ?>