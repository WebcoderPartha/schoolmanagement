
<?php $__env->startSection('title'); ?>
    Marks Entry
<?php $__env->stopSection(); ?>
<style type="text/css">
    input#marks {
        box-shadow: 2px 1px 3px 2px #ddd;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <form action="<?php echo e(route('marks.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                        <div class="row search">
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label for="year_id">Year</label>
                                    <select class="form-control" name="year_id" id="year_id">
                                        <option value="">Select year</option>
                                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($year->id); ?>"><?php echo e($year->student_year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3">

                                <div class="form-group">
                                    <label for="class_id">Class</label>
                                    <select class="form-control" name="class_id" id="class_id">
                                        <option value="">Select class</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($class->id); ?>"><?php echo e($class->class_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3">

                                <div class="form-group">
                                    <label for="class_id">Subject</label>
                                    <select class="form-control" name="subject_id" id="subject_id">
                                        <option selected value="">Select subject</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label for="exam_type_id">Exam Type</label>
                                    <select class="form-control" name="exam_type_id" id="exam_type_id">
                                        <option selected value="">Select subject</option>
                                        <?php $__currentLoopData = $examTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($examType->id); ?>"><?php echo e($examType->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 mx-auto">
                                <button type="submit" id="searchStudent" class="btn btn-primary" style="margin-top:30px">Search</button>
                            </div>
                        </div>

                </div>
            </div>
            <div class="row" id="studentMarkContent" style="display: none">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Student Marks Entry</h4>



                            <div class="table-respnsive">
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>SID</th>
                                        <th>Name</th>
                                        <th>Year</th>
                                        <th>Class</th>
                                        <th>Mark</th>
                                    </tr>
                                    </thead>
                                    <tbody class="markGenerate">


                                    </tbody>
                                </table>
                            </div>
                           <div class="submit mx-auto text-center">
                               <input class="btn btn-success" type="submit" value="Marks Entry">
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script type="text/javascript">
        $(document).ready(function (){

            // Class subject
            $(document).on('change', '#class_id', function (){
                let class_id = $(this).val();
                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(route('mark.class.subject')); ?>',
                    dataType:'JSON',
                    data: {'class_id': class_id},
                    success: function (data){
                        let html = '';
                        $.each(data.subjects, function(index, item){
                            html += '<option value='+item.subject_id+'>'+item.subject.name+'</option>';
                        });
                        if (data.subjects.length > 0){
                            $('#subject_id').html(html);
                        }else{
                            html +='<option value="">Select subject</option>';
                            $('#subject_id').html(html);
                        }

                    }
                });
            });

            $(document).on('click', '#searchStudent', function (e){
                e.preventDefault();
                let year_id = $('#year_id').val();
                let class_id = $('#class_id').val();
                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(route('assignStudentGet')); ?>',
                    dataType: 'JSON',
                    data: {year_id, class_id},
                    success:function (data){
                        let html = '';
                        $('#studentMarkContent').show();
                        $.each(data, function(index, item){

                            html += "<tr>";
                            html += "<td>"+item.student.id_number+" <input type='hidden' value="+item.student.id_number+" name='id_number[]'></td>";
                            html += "<td>"+item.student.name+"<input type='hidden' value="+item.student.id+" name='student_id[]'></td></td>";
                            html += "<td>"+item.year.student_year+"</td>";
                            html += "<td>"+item.class.class_name+"</td>";
                            html += "<td><input style='width: 130px !important;' type='text' value=''  id='marks' class='form-control' autocomplete='off' placeholder='Enter mark' name='marks[]'></td>";
                            html += "</tr>";
                        });
                        $('.markGenerate').html(html);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\slms\resources\views/backend/manage_mark/mark_view.blade.php ENDPATH**/ ?>